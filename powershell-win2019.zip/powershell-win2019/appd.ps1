#<powershell>


param([String] $dnshostname)
$file = 'C:\Program Files\appd\machineagent\conf\controller-info.xml'
$regex = '^(.*)<unique-host-id>(.*)$'

$newline = "<unique-host-id>$dnshostname</unique-host-id>"
(Get-Content $file) -replace $regex, $newline | Set-Content $file


Start-Sleep -s 10


cscript 'C:\Program Files\appd\machineagent\InstallService.vbs'

Start-Sleep -s 10

#</powershell>


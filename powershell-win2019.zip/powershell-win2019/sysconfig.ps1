#<powershell>
param([String] $dnshostname)

Rename-Computer -NewName $dnshostname

"C:\Program Files (x86)\Symantec\Symantec Endpoint Protection\SepLiveUpdate.exe"

Start-Sleep -s 360

Restart-Computer 

#<powershell>

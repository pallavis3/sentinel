write-host "running db-server script"

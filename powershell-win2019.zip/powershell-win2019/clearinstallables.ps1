#<powershell>

Remove-Item 'C:\securityagents' -Recurse

#Start-Sleep -s 150

#"C:\Program Files (x86)\Symantec\Symantec Endpoint Protection\SepLiveUpdate.exe"

#Start-Sleep -s 150

#Restart-Computer
#<powershell>

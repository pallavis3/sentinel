#<powershell>
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Common" /v CheckServerCertificate /t REG_SZ /d False /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\ManageSoft Corp\ManageSoft\Common" /v CheckCertificateRevocation /t REG_SZ /d False /f
Start-Process -NoNewWindow -FilePath "C:\Program Files (x86)\ManageSoft\Policy Client\mgspolicy.exe" -ArgumentList "-t machine"

#</powershell>

param(
[Parameter(Mandatory = $false)][string]$enrollment_token,
[Parameter(Mandatory = $false)][string]$canonical_name,
[Parameter(Mandatory = $false)][string]$bastion_name,
[Parameter(Mandatory = $false)][string]$dnshostname
)

.\oktaasa-jfrog.ps1 $enrollment_token $canonical_name $bastion_name
.\appd.ps1 $dnshostname
.\sysconfig.ps1 $dnshostname
.\splunk.ps1 $dnshostname
.\flexera.ps1
.\dcs.ps1
.\formatdrives.ps1
.\clearinstallables.ps1
.\dbserverscript.ps1

#<powershell>

param([String] $dnshostname)


Start-Sleep -s 30

net stop SplunkForwarder


Start-Sleep -s 10



# $file_input = 'C:\Program Files\SplunkUniversalForwarder\etc\system\local\inputs.conf'

# $regex_input = '^(.*)host(.*)$'

# $newline_input = "host $dnshostname"
# (Get-Content $file_input) -replace $regex_input, $newline_input | Set-Content $file_input


# Start-Sleep -s 10


$file_server = 'C:\Program Files\SplunkUniversalForwarder\etc\system\local\server.conf'

$regex_server = '^(.*)serverName(.*)$'

$newline_server = "serverName = $dnshostname"
(Get-Content $file_server) -replace $regex_server, $newline_server | Set-Content $file_server


Start-Sleep -s 10


net start SplunkForwarder


#</powershell>

# #<powershell>


# ##cd "C:\Program Files (x86)\Symantec\Data Center Security Server\Agent\IPS\bin\"
# #sisservicectrl.exe stop sisipsservice

# #Start-Sleep -s 10

# #cd "C:\Program Files (x86)\Symantec\Data Center Security Server\Agent\IPS\bin\"
# #sisservicectrl.exe stop sisidsservice

# #Start-Sleep -s 10

# #cd "C:\Program Files (x86)\Symantec\Data Center Security Server\Agent\IPS\bin\"
# #sisservicectrl.exe stop sisipsutil

# Start-Sleep -s 10

# cd "C:\Program Files (x86)\Symantec\Data Center Security Server\Agent\IPS\bin\"
# sisipsconfig.exe -forcereg

# Start-Sleep -s 10

# #cd "C:\Program Files (x86)\Symantec\Data Center Security Server\Agent\IPS\bin\"
# #sisservicectrl.exe start sisipsservice

# #Start-Sleep -s 10

# #cd "C:\Program Files (x86)\Symantec\Data Center Security Server\Agent\IPS\bin\"
# #sisservicectrl.exe start sisidsservice

# #Start-Sleep -s 10

# #cd "C:\Program Files (x86)\Symantec\Data Center Security Server\Agent\IPS\bin\"
# #sisservicectrl.exe start sisipsutil

# #Start-Sleep -s 10

# #</powershell>


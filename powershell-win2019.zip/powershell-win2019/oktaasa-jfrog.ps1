# Install ScaleFT Server Tools from JFROG Artifactory

param(
    [Parameter(Mandatory = $false)][string]$enrollment_token,

    [Parameter(Mandatory = $false)][string]$canonical_name,

    [Parameter(Mandatory = $false)][string]$bastion_name
)


$ErrorActionPreference = "Stop"
$ErrorView = "CategoryView"

function Stop-ScaleFTService() {
    $installed = [bool](Get-Service | Where-Object Name -eq "scaleft-server-tools")
    if ($installed -eq $true) {
        echo "Stoping Service scaleft-server-tools"
        Stop-Service -Name "scaleft-server-tools"
        return $true
    }
    return $false
}

function Start-ScaleFTService() {
    $installed = [bool](Get-Service | Where-Object Name -eq "scaleft-server-tools")
    if ($installed -eq $true) {
        echo "Starting Service scaleft-server-tools"
        Start-Service -Name "scaleft-server-tools"
        return $true
    }
    return $false
}

function Install-ScaleFTServerTools() {
    param(

        [Parameter(Mandatory = $false)][string]$EnrollmentToken,

        [Parameter(Mandatory = $false)][string]$CanonicalName,

        [Parameter(Mandatory = $false)][string]$Bastion
    )
    process {
        $ErrorActionPreference = "Stop";

        # Select Local System User, where the ScaleFT Server Agent Runs
        $systemprofile = (Get-WmiObject win32_userprofile  | where-object sid -eq "S-1-5-18" | select -ExpandProperty localpath)
        $stateDir = Join-Path $systemprofile -ChildPath 'AppData' | Join-Path -ChildPath "Local" | Join-Path -ChildPath "ScaleFT"

        # Write Enrollment Token to File
        if ($PSBoundParameters.ContainsKey("EnrollmentToken")) {
            echo "writing enrollment token to file..."
            $tokenPath = Join-Path $stateDir -ChildPath "enrollment.token"
            New-Item -ItemType directory -Path $stateDir -force
            $EnrollmentToken | Out-File $tokenPath -Encoding "ASCII" -Force
        }

        # Write SFTD.yaml file
        if ($PSBoundParameters.ContainsKey("CanonicalName")) {
            echo "writing canonical name to file..."
            $configPath = Join-Path $stateDir -ChildPath "sftd.yaml"
            New-Item -ItemType directory -Path $stateDir -force
            "CanonicalName: $($CanonicalName)"  | Out-File $configPath -Append -Encoding "ASCII" -Force
        }

        if ($PSBoundParameters.ContainsKey("Bastion")) {
            echo "writing bastion name to file..."
            $configPath = Join-Path $stateDir -ChildPath "sftd.yaml"
            New-Item -ItemType directory -Path $stateDir -force
            "Bastion: $($Bastion)"  | Out-File $configPath -Append -Encoding "ASCII" -Force
        }

        # Stop and restart ScaleFT Service to apply configuration file changes
        $stopped = Stop-ScaleFTService
        if ($stopped -eq $true) {
            Start-ScaleFTService
        }

        # Check if ScaleFTService is already installed, skip install if it is
        $installed = [bool](Get-Service | Where-Object Name -eq "scaleft-server-tools")
        if ($installed -eq $false) {
            # Configure MSI Path and Log
            $msiPath = [System.IO.Path]::ChangeExtension([System.IO.Path]::GetTempFileName(), '.msi')
            $msiLog = [System.IO.Path]::ChangeExtension($msiPath, '.log')

            # Download MSI From Artifactory
            $pair = "aws-rhel-agent-install:LLaTSni7TneH23a"
            $encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
            $basicAuthValue = "Basic $encodedCreds"
            $header = @{
                Authorization = $basicAuthValue
            }
            echo "downloading scaleft MSI from jfrog..."
            Invoke-WebRequest -ContentType "application/zip" -UseBasicParsing -Method "Get" -Headers $header -Uri "https://artifactory.farmersinsurance.com/artifactory/aws_windows_agent_installables/ScaleFT-Server-Tools-1.54.0.msi" -OutFile $msiPath

            # Run MSI Installer
            echo "Starting msiexec on $($msiPath)"
            echo "MSI Log path: $($msiLog)"
            $status = Start-Process -FilePath msiexec -ArgumentList /i, $msiPath, /qn, /L*V!, $msiLog  -Wait -PassThru
            if ($status.ExitCode -ne 0) {
                Start-ScaleFTService
                throw "msiexec failed with exit code: $($status.ExitCode) Log: $($msiLog)"
            }
                
            # Clean up temporary files
            echo "Removing $($msiPath)"
            Remove-Item -Force $msiPath

            # Start ScaleFT Service after Install
            Start-ScaleFTService
        }
        else {
            echo "ScaleFTService is already installed..."
        }
    }
}

Install-ScaleFTServerTools -EnrollmentToken "${enrollment_token}" -CanonicalName "${canonical_name}" -Bastion "${bastion_name}"

exit
